<?php
namespace app\forms;

use std, gui, framework, app;


class info extends AbstractForm
{

    /**
     * @event button.click 
     */
    function doButtonClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label4.click 
     */
    function doLabel4Click(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event label3.click 
     */
    function doLabel3Click(UXMouseEvent $e = null)
    {    
        
    }

}
