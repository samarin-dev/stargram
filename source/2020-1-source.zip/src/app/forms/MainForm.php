<?php
namespace app\forms;

use bundle\jurl\jURL;
use std, gui, framework, app;


class MainForm extends AbstractForm
{

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {   
        //$ua = "Chrome/80.0.3987.132 Mobile"; 
        //jURL->setUserAgent($ua);
        $this->browser->engine->userDataDirectory = "data/user";
        $this->browser->engine->javaScriptEnabled = true;
        $this->browser->engine->userAgent = "Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; SCH-I535 Build/KOT49H) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30";
    }

    /**
     * @event circle.mouseEnter 
     */
    function doCircleMouseEnter(UXMouseEvent $e = null)
    {
        $this->circle->strokeColor = white;
    }

    /**
     * @event circle.mouseExit 
     */
    function doCircleMouseExit(UXMouseEvent $e = null)
    {
        $this->circle->strokeColor = grav;
    }

    /**
     * @event circle.click 
     */
    function doCircleClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circleAlt.mouseEnter 
     */
    function doCircleAltMouseEnter(UXMouseEvent $e = null)
    {
        $this->circleAlt->strokeColor = red;
    }

    /**
     * @event circleAlt.mouseExit 
     */
    function doCircleAltMouseExit(UXMouseEvent $e = null)
    {
        $this->circleAlt->strokeColor = grav;
    }

    /**
     * @event circleAlt.click 
     */
    function doCircleAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event circle3.mouseEnter 
     */
    function doCircle3MouseEnter(UXMouseEvent $e = null)
    {
        $this->circle3->strokeColor = green;
    }

    /**
     * @event circle3.mouseExit 
     */
    function doCircle3MouseExit(UXMouseEvent $e = null)
    {
        $this->circle3->strokeColor = grav;
    }

    /**
     * @event circle3.click 
     */
    function doCircle3Click(UXMouseEvent $e = null)
    {
        if ($this->width < 800)
        {
            $this->maximize();
        }
        else 
        {
            $this->fullScreen = false;
            $this->width = 700;
            $this->height = 500;
        }
    }

    /**
     * @event circle4.mouseEnter 
     */
    function doCircle4MouseEnter(UXMouseEvent $e = null)
    {
        $this->circle4->strokeColor = blue;
    }

    /**
     * @event circle4.mouseExit 
     */
    function doCircle4MouseExit(UXMouseEvent $e = null)
    {
        $this->circle4->strokeColor = grav;
    }

    /**
     * @event circle4.click 
     */
    function doCircle4Click(UXMouseEvent $e = null)
    {
        
    }

    /**
     * @event browser.fail 
     */
    function doBrowserFail(UXEvent $e = null)
    {    
        $this->toast('Не удалось выполнить соединение с сервером Instagram, повторите попытку позже.');
    }

    /**
     * @event browser.running 
     */
    function doBrowserRunning(UXEvent $e = null)
    {    
        $this->toast('Загружаем...');
    }

}
